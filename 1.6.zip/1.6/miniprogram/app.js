var config = require('utils/config.js');

App({
    onLaunch: function () {

        if (!wx.cloud) {
            console.error('请使用 2.2.3 或以上的基础库以使用云能力')
          } else {
            wx.cloud.init({
              // env 参数说明：
              //   env 参数决定接下来小程序发起的云开发调用（wx.cloud.xxx）会默认请求到哪个云环境的资源
              //   此处请填入环境 ID, 环境 ID 可打开云控制台查看
              //   如不填则使用默认环境（第一个创建的环境）
              // env: 'my-env-id',
              traceUser: true,
            })
          }
        var that = this;
        wx.login({
            success: function (res) {
                that.globalData.loginRes = res;
            }
        });
    },

    /* 获取userinfo */
    getUserInfo: function (cb) {
        var that = this;
        if (that.globalData.userInfo) {
            typeof cb == "function" && cb(that.globalData.userInfo)
        } else {
            that.libLogin(cb);
        }
    },

    /* 图书馆登录 */
    libLogin: function (cb) {
        var that = this;
        var res = this.globalData.loginRes;
        wx.getUserInfo({
            success: function (r) {
                wx.request({
                    url: config.baseUrl + '/user/login',
                    data: {
                        code: res.code,
                        iv: r.iv,
                        encryptedData: r.encryptedData
                    },
                    header: { "Content-Type": "application/x-www-form-urlencoded" },
                    method: 'POST',
                    success: function (res) {
                        that.globalData.userInfo = res.data
                        wx.setStorageSync('token', that.globalData.userInfo.token)
                        typeof cb == "function" && cb(that.globalData.userInfo)
                    }
                })
            }
        })
    },
    baseUrl: config.baseUrl,
    provinces: config.provinces,
    schools: config.schools,
    codes: config.codes,
    globalData: {
        userInfo: null,
        loginRes: null,
        xmz:null
    }
})
