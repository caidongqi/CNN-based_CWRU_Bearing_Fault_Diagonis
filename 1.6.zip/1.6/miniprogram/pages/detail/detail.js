var app = getApp();
Page({
    data: {
        book_author: "",
        code: "",
        books: [],
        book_name: "加载中...",
        description: {},
        mounted: false,
        school: "",
        is_faved: false,
        marc_no: "",
        ctrl_no: '',
        //页面配置
        scroll_height: 0,
        winWidth: 0,
        winHeight: 0,
        currentTab: 0,
        idx:0
    },

    onPullDownRefresh: function () {
        wx.stopPullDownRefresh();
    },

    navToDetail2() {
    wx.navigateTo({
      url: '/pages/detail2/detail2?idx='+this.data.idx,
      })
    },
    onLoad:function(options){
      console.log(options.idx)
      this.setData({idx:options.idx})
    }
})