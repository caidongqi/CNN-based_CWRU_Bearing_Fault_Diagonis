// miniprogram/pages/logs/logs.js
import * as echarts from '../../ec-canvas/echarts';
const app = getApp()

//初始化cloud
wx.cloud.init()
const db = wx.cloud.database({env:'test-c0dqx'})


Page({

  /**
   * 页面的初始数据
   */
  data: {
    cloud_report:[],
    ec: {
      lazyLoad: false // 延迟加载
    }, //饼图

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.piechartsComponnet = this.selectComponent('#mychart-dom-bar');
    this.init_pieCharts()

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this

    // 调用云函数获取报告记录
    db.collection('report').get().then(res => {
      // res.data 包含该记录的数据
      console.log(res.data[0])
      that.setData({cloud_report:res.data})
    })
    


  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  newReport:function(){
    wx.navigateTo({
      url: '/pages/newReport/newReport',
    })
  },
  init_pieCharts: function() {
    this.piechartsComponnet.init((canvas, width, height) => {
      // 初始化图表
      const pieChart = echarts.init(canvas, null, {
        width: width,
        height: height
      });
      pieChart.setOption(this.getPieOption());
      // 注意这里一定要返回 chart 实例，否则会影响事件处理等
      return pieChart;
    });
  },
   //饼图
   getPieOption: function() {
    var option = {
      tooltip: {
        show: true,
        formatter: "{a} <br/>{b} : {c} ({d}%)"
      },
      toolbox: {
        show: true,
        feature: {
          mark: {
            show: true
          },
          dataView: {
            show: true,
            readOnly: false
          },
          restore: {
            show: true
          },
          saveAsImage: {
            show: true
          }
        }
      },
      color: ['#56cbff', '#ff6300'],
      calculable: true,
      series: [{
        name: '分类',
        type: 'pie',
        center: ['50%', '50%'],
        radius: 80,
        itemStyle: {
          normal: {
            label: {
              show: true,
              position: 'inner',
              formatter: function(params) {
                return (params.percent - 0).toFixed(0) + '%'
              }
            },
            labelLine: {
              show: false
            }
          },
          emphasis: {
            label: {
              show: true,
              formatter: "{b}\n{d}%"
            }
          }
        },
        data: [{
            value: 99,
            name: 'A'
          },
          {
            value:1,
            name: 'B'
          }
        ]
      }]
    };
    return option;
  },



})