/*

 */

var app = getApp()

Page({
	data: {
		userInfo: {},
		items: [
			{
				text: '维修零件库存',
				path: '../fav/fav'
			},
		],
		settings: [
			{
				icon: 'businesscard',
				text: '联系维修员',
			}
		]
	},

	onPullDownRefresh: function () {
		wx.stopPullDownRefresh();
	},
	/* 页面加载 */
	onLoad: function () {
		var that = this;
		app.getUserInfo(function (res) {
			that.setData({
				userInfo: res
			})
		})
	},

	/* 页面显示 */
	onShow: function () {
		var that = this;
		that.showCurrentStorage();
	},

	/* 显示维修零件库存 */
	navigateTo: function (e) {
		var index = e.currentTarget.dataset.index;
		var path = e.currentTarget.dataset.path;
		wx.navigateTo({
			url: path
		});
	},

	/* 联系维修员 */
	bindtap: function (e) {
		var that = this;
		var index = e.currentTarget.dataset.index;
		var path = e.currentTarget.dataset.path;
		wx.showModal({
			title: '友情提示',
			content: '确定要拨打电话吗？',
		})
  }
})