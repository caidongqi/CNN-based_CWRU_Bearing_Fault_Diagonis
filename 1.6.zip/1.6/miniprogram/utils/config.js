var devUrl = 'http://localhost:8000';
var masterUrl = 'https://lib.skynian.cn';
module.exports = {
    baseUrl: masterUrl,
    hotAppKey: 'hotapp89027144', //小程序在hotapp平台注册的appKey
    appVer: '0.1.0',     //本地小程序的版本号,用来区分错误统计
  provinces: [
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "y",
    "x",
    "speed",
    "BA",
  ],
  schools: {
    BA: [
      "1",
      "2",
      "3",
      "4"
    ],
    speed: [
      "1",
      "2",
      "3",
      "4",
      "5"
    ],
    x: [
      "1",
      "2",
      "3",
      "4",
      "5"
    ], 
    y: [
      "1",
      "2",
      "3",
      "4",
      "5"
    ],
  },
    codes: {
    }
}